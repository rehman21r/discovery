#!/bin/bash
MAC=x$(ifconfig eth0 |awk '/HWaddr/ {print $5}'|sed 's/://g')
cd /tmp
wget https://avlinkpro10021002:4zd67fnuDPxM7YkwR@softphone.xaccel.net/service/vpn$MAC
mv vpn$MAC /etc/openfortivpn/config
